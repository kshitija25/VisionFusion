import download from './download.png';
import logo from './logo.png';
import preview from './preview.png';
import logo2 from './logo.svg';

export {
  download,
  logo,
  preview,
  logo2,
};
